﻿namespace veritabani
{
    partial class Kisi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ibListele = new System.Windows.Forms.Button();
            this.ibEkle = new System.Windows.Forms.Button();
            this.ibSil = new System.Windows.Forms.Button();
            this.ibGuncelle = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ibkisino = new System.Windows.Forms.TextBox();
            this.telefon = new System.Windows.Forms.TextBox();
            this.adres = new System.Windows.Forms.TextBox();
            this.ilceno = new System.Windows.Forms.TextBox();
            this.ibno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dbKisi = new System.Windows.Forms.DataGridView();
            this.btCikis = new System.Windows.Forms.Button();
            this.btKListele = new System.Windows.Forms.Button();
            this.cbTur = new System.Windows.Forms.ComboBox();
            this.btAra = new System.Windows.Forms.Button();
            this.btGuncelle = new System.Windows.Forms.Button();
            this.btSil = new System.Windows.Forms.Button();
            this.btEkle = new System.Windows.Forms.Button();
            this.ad = new System.Windows.Forms.TextBox();
            this.soyad = new System.Windows.Forms.TextBox();
            this.kisino = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tckimlik = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.KBkisino = new System.Windows.Forms.TextBox();
            this.datedogum = new System.Windows.Forms.DateTimePicker();
            this.datekayit = new System.Windows.Forms.DateTimePicker();
            this.KBlistele = new System.Windows.Forms.Button();
            this.KBguncelle = new System.Windows.Forms.Button();
            this.KBsil = new System.Windows.Forms.Button();
            this.KBekle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dbKisi)).BeginInit();
            this.SuspendLayout();
            // 
            // ibListele
            // 
            this.ibListele.Location = new System.Drawing.Point(45, 657);
            this.ibListele.Name = "ibListele";
            this.ibListele.Size = new System.Drawing.Size(92, 52);
            this.ibListele.TabIndex = 109;
            this.ibListele.Text = "LİSTELE";
            this.ibListele.UseVisualStyleBackColor = true;
            this.ibListele.Click += new System.EventHandler(this.ibListele_Click);
            // 
            // ibEkle
            // 
            this.ibEkle.Location = new System.Drawing.Point(176, 657);
            this.ibEkle.Name = "ibEkle";
            this.ibEkle.Size = new System.Drawing.Size(91, 52);
            this.ibEkle.TabIndex = 108;
            this.ibEkle.Text = "EKLE";
            this.ibEkle.UseVisualStyleBackColor = true;
            this.ibEkle.Click += new System.EventHandler(this.ibEkle_Click);
            // 
            // ibSil
            // 
            this.ibSil.Location = new System.Drawing.Point(301, 657);
            this.ibSil.Name = "ibSil";
            this.ibSil.Size = new System.Drawing.Size(94, 52);
            this.ibSil.TabIndex = 107;
            this.ibSil.Text = "SİL";
            this.ibSil.UseVisualStyleBackColor = true;
            this.ibSil.Click += new System.EventHandler(this.ibSil_Click);
            // 
            // ibGuncelle
            // 
            this.ibGuncelle.Location = new System.Drawing.Point(440, 657);
            this.ibGuncelle.Name = "ibGuncelle";
            this.ibGuncelle.Size = new System.Drawing.Size(92, 52);
            this.ibGuncelle.TabIndex = 106;
            this.ibGuncelle.Text = "GÜNCELLE";
            this.ibGuncelle.UseVisualStyleBackColor = true;
            this.ibGuncelle.Click += new System.EventHandler(this.ibGuncelle_Click);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(170, 584);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 22);
            this.label14.TabIndex = 105;
            this.label14.Text = "Kişi No:";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(170, 412);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(132, 22);
            this.label13.TabIndex = 104;
            this.label13.Text = "No:";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(170, 454);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 22);
            this.label12.TabIndex = 103;
            this.label12.Text = "Telefon:";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(170, 499);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 22);
            this.label11.TabIndex = 102;
            this.label11.Text = "Adres:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(170, 543);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 22);
            this.label10.TabIndex = 101;
            this.label10.Text = "İlce No:";
            // 
            // ibkisino
            // 
            this.ibkisino.Location = new System.Drawing.Point(326, 584);
            this.ibkisino.Name = "ibkisino";
            this.ibkisino.Size = new System.Drawing.Size(206, 27);
            this.ibkisino.TabIndex = 100;
            // 
            // telefon
            // 
            this.telefon.Location = new System.Drawing.Point(326, 449);
            this.telefon.Name = "telefon";
            this.telefon.Size = new System.Drawing.Size(206, 27);
            this.telefon.TabIndex = 99;
            // 
            // adres
            // 
            this.adres.Location = new System.Drawing.Point(326, 494);
            this.adres.Name = "adres";
            this.adres.Size = new System.Drawing.Size(206, 27);
            this.adres.TabIndex = 98;
            // 
            // ilceno
            // 
            this.ilceno.Location = new System.Drawing.Point(326, 538);
            this.ilceno.Name = "ilceno";
            this.ilceno.Size = new System.Drawing.Size(206, 27);
            this.ilceno.TabIndex = 97;
            // 
            // ibno
            // 
            this.ibno.Location = new System.Drawing.Point(326, 407);
            this.ibno.Name = "ibno";
            this.ibno.Size = new System.Drawing.Size(206, 27);
            this.ibno.TabIndex = 96;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(170, 366);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(301, 53);
            this.label5.TabIndex = 95;
            this.label5.Text = "İLETİŞİM BİLGİLERİ";
            // 
            // dbKisi
            // 
            this.dbKisi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dbKisi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbKisi.Location = new System.Drawing.Point(12, 12);
            this.dbKisi.Name = "dbKisi";
            this.dbKisi.RowHeadersWidth = 51;
            this.dbKisi.RowTemplate.Height = 29;
            this.dbKisi.Size = new System.Drawing.Size(654, 321);
            this.dbKisi.TabIndex = 94;
            // 
            // btCikis
            // 
            this.btCikis.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btCikis.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCikis.Location = new System.Drawing.Point(1541, 584);
            this.btCikis.Name = "btCikis";
            this.btCikis.Size = new System.Drawing.Size(144, 74);
            this.btCikis.TabIndex = 146;
            this.btCikis.Text = "ÇIKIŞ";
            this.btCikis.UseVisualStyleBackColor = false;
            this.btCikis.Click += new System.EventHandler(this.btCikis_Click);
            // 
            // btKListele
            // 
            this.btKListele.Location = new System.Drawing.Point(760, 244);
            this.btKListele.Name = "btKListele";
            this.btKListele.Size = new System.Drawing.Size(123, 52);
            this.btKListele.TabIndex = 145;
            this.btKListele.Text = "LİSTELE";
            this.btKListele.UseVisualStyleBackColor = true;
            this.btKListele.Click += new System.EventHandler(this.btKListele_Click);
            // 
            // cbTur
            // 
            this.cbTur.FormattingEnabled = true;
            this.cbTur.Location = new System.Drawing.Point(1106, 183);
            this.cbTur.Name = "cbTur";
            this.cbTur.Size = new System.Drawing.Size(323, 28);
            this.cbTur.TabIndex = 144;
            // 
            // btAra
            // 
            this.btAra.Location = new System.Drawing.Point(1469, 244);
            this.btAra.Name = "btAra";
            this.btAra.Size = new System.Drawing.Size(123, 52);
            this.btAra.TabIndex = 143;
            this.btAra.Text = "ARA";
            this.btAra.UseVisualStyleBackColor = true;
            this.btAra.Click += new System.EventHandler(this.btAra_Click);
            // 
            // btGuncelle
            // 
            this.btGuncelle.Location = new System.Drawing.Point(1291, 244);
            this.btGuncelle.Name = "btGuncelle";
            this.btGuncelle.Size = new System.Drawing.Size(123, 52);
            this.btGuncelle.TabIndex = 142;
            this.btGuncelle.Text = "GÜNCELLE";
            this.btGuncelle.UseVisualStyleBackColor = true;
            this.btGuncelle.Click += new System.EventHandler(this.btGuncelle_Click);
            // 
            // btSil
            // 
            this.btSil.Location = new System.Drawing.Point(1106, 244);
            this.btSil.Name = "btSil";
            this.btSil.Size = new System.Drawing.Size(123, 52);
            this.btSil.TabIndex = 141;
            this.btSil.Text = "SİL";
            this.btSil.UseVisualStyleBackColor = true;
            this.btSil.Click += new System.EventHandler(this.btSil_Click);
            // 
            // btEkle
            // 
            this.btEkle.Location = new System.Drawing.Point(925, 244);
            this.btEkle.Name = "btEkle";
            this.btEkle.Size = new System.Drawing.Size(123, 52);
            this.btEkle.TabIndex = 140;
            this.btEkle.Text = "EKLE";
            this.btEkle.UseVisualStyleBackColor = true;
            this.btEkle.Click += new System.EventHandler(this.btEkle_Click);
            // 
            // ad
            // 
            this.ad.Location = new System.Drawing.Point(1106, 108);
            this.ad.Name = "ad";
            this.ad.Size = new System.Drawing.Size(323, 27);
            this.ad.TabIndex = 139;
            // 
            // soyad
            // 
            this.soyad.Location = new System.Drawing.Point(1106, 141);
            this.soyad.Name = "soyad";
            this.soyad.Size = new System.Drawing.Size(323, 27);
            this.soyad.TabIndex = 138;
            // 
            // kisino
            // 
            this.kisino.Location = new System.Drawing.Point(1106, 74);
            this.kisino.Name = "kisino";
            this.kisino.Size = new System.Drawing.Size(323, 27);
            this.kisino.TabIndex = 137;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(953, 185);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 22);
            this.label9.TabIndex = 136;
            this.label9.Text = "Kişi Tür:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(953, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 22);
            this.label8.TabIndex = 135;
            this.label8.Text = "Kişi No:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(953, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 22);
            this.label7.TabIndex = 134;
            this.label7.Text = "Ad:";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(953, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 22);
            this.label6.TabIndex = 133;
            this.label6.Text = "Soyad:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(1081, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 53);
            this.label1.TabIndex = 132;
            this.label1.Text = "KİŞİ İŞLEMLERİ";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(1081, 352);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(276, 53);
            this.label2.TabIndex = 147;
            this.label2.Text = "KİŞİSEL BİLGİLER";
            // 
            // tckimlik
            // 
            this.tckimlik.Location = new System.Drawing.Point(1081, 412);
            this.tckimlik.Name = "tckimlik";
            this.tckimlik.Size = new System.Drawing.Size(323, 27);
            this.tckimlik.TabIndex = 153;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(928, 561);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 22);
            this.label3.TabIndex = 152;
            this.label3.Text = "Kisi No:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(928, 416);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 22);
            this.label4.TabIndex = 151;
            this.label4.Text = "TC kimlik No:";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(928, 467);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 22);
            this.label15.TabIndex = 150;
            this.label15.Text = "Doğum Tarihi:";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(928, 510);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(132, 22);
            this.label16.TabIndex = 149;
            this.label16.Text = "Kayıt Tarihi:";
            // 
            // KBkisino
            // 
            this.KBkisino.Location = new System.Drawing.Point(1081, 557);
            this.KBkisino.Name = "KBkisino";
            this.KBkisino.Size = new System.Drawing.Size(323, 27);
            this.KBkisino.TabIndex = 154;
            // 
            // datedogum
            // 
            this.datedogum.Location = new System.Drawing.Point(1081, 464);
            this.datedogum.Name = "datedogum";
            this.datedogum.Size = new System.Drawing.Size(323, 27);
            this.datedogum.TabIndex = 155;
            // 
            // datekayit
            // 
            this.datekayit.Location = new System.Drawing.Point(1081, 514);
            this.datekayit.Name = "datekayit";
            this.datekayit.Size = new System.Drawing.Size(323, 27);
            this.datekayit.TabIndex = 156;
            // 
            // KBlistele
            // 
            this.KBlistele.Location = new System.Drawing.Point(760, 616);
            this.KBlistele.Name = "KBlistele";
            this.KBlistele.Size = new System.Drawing.Size(123, 52);
            this.KBlistele.TabIndex = 161;
            this.KBlistele.Text = "LİSTELE";
            this.KBlistele.UseVisualStyleBackColor = true;
            this.KBlistele.Click += new System.EventHandler(this.KBlistele_Click);
            // 
            // KBguncelle
            // 
            this.KBguncelle.Location = new System.Drawing.Point(1291, 616);
            this.KBguncelle.Name = "KBguncelle";
            this.KBguncelle.Size = new System.Drawing.Size(123, 52);
            this.KBguncelle.TabIndex = 159;
            this.KBguncelle.Text = "GÜNCELLE";
            this.KBguncelle.UseVisualStyleBackColor = true;
            this.KBguncelle.Click += new System.EventHandler(this.KBguncelle_Click);
            // 
            // KBsil
            // 
            this.KBsil.Location = new System.Drawing.Point(1106, 616);
            this.KBsil.Name = "KBsil";
            this.KBsil.Size = new System.Drawing.Size(123, 52);
            this.KBsil.TabIndex = 158;
            this.KBsil.Text = "SİL";
            this.KBsil.UseVisualStyleBackColor = true;
            this.KBsil.Click += new System.EventHandler(this.KBsil_Click);
            // 
            // KBekle
            // 
            this.KBekle.Location = new System.Drawing.Point(925, 616);
            this.KBekle.Name = "KBekle";
            this.KBekle.Size = new System.Drawing.Size(123, 52);
            this.KBekle.TabIndex = 157;
            this.KBekle.Text = "EKLE";
            this.KBekle.UseVisualStyleBackColor = true;
            this.KBekle.Click += new System.EventHandler(this.KBekle_Click);
            // 
            // Kisi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1755, 732);
            this.Controls.Add(this.KBlistele);
            this.Controls.Add(this.KBguncelle);
            this.Controls.Add(this.KBsil);
            this.Controls.Add(this.KBekle);
            this.Controls.Add(this.datekayit);
            this.Controls.Add(this.datedogum);
            this.Controls.Add(this.KBkisino);
            this.Controls.Add(this.tckimlik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btCikis);
            this.Controls.Add(this.btKListele);
            this.Controls.Add(this.cbTur);
            this.Controls.Add(this.btAra);
            this.Controls.Add(this.btGuncelle);
            this.Controls.Add(this.btSil);
            this.Controls.Add(this.btEkle);
            this.Controls.Add(this.ad);
            this.Controls.Add(this.soyad);
            this.Controls.Add(this.kisino);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ibListele);
            this.Controls.Add(this.ibEkle);
            this.Controls.Add(this.ibSil);
            this.Controls.Add(this.ibGuncelle);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ibkisino);
            this.Controls.Add(this.telefon);
            this.Controls.Add(this.adres);
            this.Controls.Add(this.ilceno);
            this.Controls.Add(this.ibno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dbKisi);
            this.Name = "Kisi";
            this.Text = "Kisi";
            this.Load += new System.EventHandler(this.Kisi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dbKisi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button ibListele;
        private Button ibEkle;
        private Button ibSil;
        private Button ibGuncelle;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private TextBox ibkisino;
        private TextBox telefon;
        private TextBox adres;
        private TextBox ilceno;
        private TextBox ibno;
        private Label label5;
        private DataGridView dbKisi;
        private Button btCikis;
        private Button btKListele;
        private ComboBox cbTur;
        private Button btAra;
        private Button btGuncelle;
        private Button btSil;
        private Button btEkle;
        private TextBox ad;
        private TextBox soyad;
        private TextBox kisino;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label1;
        private Label label2;
        private TextBox tckimlik;
        private Label label3;
        private Label label4;
        private Label label15;
        private Label label16;
        private TextBox KBkisino;
        private DateTimePicker datedogum;
        private DateTimePicker datekayit;
        private Button KBlistele;
        private Button KBguncelle;
        private Button KBsil;
        private Button KBekle;
    }
}