﻿namespace veritabani
{
    partial class Urun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dbUrun = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Kurunkod = new System.Windows.Forms.TextBox();
            this.Kyayinevi = new System.Windows.Forms.TextBox();
            this.Kkategori = new System.Windows.Forms.TextBox();
            this.Kyazar = new System.Windows.Forms.TextBox();
            this.Kad = new System.Windows.Forms.TextBox();
            this.Ktip = new System.Windows.Forms.ComboBox();
            this.Klistele = new System.Windows.Forms.Button();
            this.Kara = new System.Windows.Forms.Button();
            this.Kguncelle = new System.Windows.Forms.Button();
            this.Ksil = new System.Windows.Forms.Button();
            this.Kekle = new System.Windows.Forms.Button();
            this.btCikis = new System.Windows.Forms.Button();
            this.Ftip = new System.Windows.Forms.ComboBox();
            this.Fad = new System.Windows.Forms.TextBox();
            this.Fyil = new System.Windows.Forms.TextBox();
            this.Fkategori = new System.Windows.Forms.TextBox();
            this.Furunkod = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Fekle = new System.Windows.Forms.Button();
            this.Fsil = new System.Windows.Forms.Button();
            this.Fguncelle = new System.Windows.Forms.Button();
            this.Fara = new System.Windows.Forms.Button();
            this.Flistele = new System.Windows.Forms.Button();
            this.btToplam = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dbUrun)).BeginInit();
            this.SuspendLayout();
            // 
            // dbUrun
            // 
            this.dbUrun.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dbUrun.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbUrun.Location = new System.Drawing.Point(12, 12);
            this.dbUrun.Name = "dbUrun";
            this.dbUrun.RowHeadersWidth = 51;
            this.dbUrun.RowTemplate.Height = 29;
            this.dbUrun.Size = new System.Drawing.Size(780, 318);
            this.dbUrun.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(1113, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(198, 34);
            this.label4.TabIndex = 70;
            this.label4.Text = "KİTAP İŞLEMLERİ";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(287, 346);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 34);
            this.label2.TabIndex = 72;
            this.label2.Text = "FİLM İŞLEMLERİ";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(865, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 33);
            this.label1.TabIndex = 73;
            this.label1.Text = "Yayınevi No:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(865, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 33);
            this.label3.TabIndex = 74;
            this.label3.Text = "Kategori No:";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(865, 199);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(198, 33);
            this.label5.TabIndex = 75;
            this.label5.Text = "Yazar No:";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(865, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(198, 33);
            this.label6.TabIndex = 76;
            this.label6.Text = "Adı:";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(865, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(198, 33);
            this.label7.TabIndex = 77;
            this.label7.Text = "Ürün Kodu:";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(865, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(198, 33);
            this.label8.TabIndex = 78;
            this.label8.Text = "Ürün Tipi:";
            // 
            // Kurunkod
            // 
            this.Kurunkod.Location = new System.Drawing.Point(1043, 69);
            this.Kurunkod.Name = "Kurunkod";
            this.Kurunkod.Size = new System.Drawing.Size(351, 27);
            this.Kurunkod.TabIndex = 79;
            // 
            // Kyayinevi
            // 
            this.Kyayinevi.Location = new System.Drawing.Point(1043, 294);
            this.Kyayinevi.Name = "Kyayinevi";
            this.Kyayinevi.Size = new System.Drawing.Size(351, 27);
            this.Kyayinevi.TabIndex = 80;
            // 
            // Kkategori
            // 
            this.Kkategori.Location = new System.Drawing.Point(1043, 246);
            this.Kkategori.Name = "Kkategori";
            this.Kkategori.Size = new System.Drawing.Size(351, 27);
            this.Kkategori.TabIndex = 81;
            // 
            // Kyazar
            // 
            this.Kyazar.Location = new System.Drawing.Point(1043, 199);
            this.Kyazar.Name = "Kyazar";
            this.Kyazar.Size = new System.Drawing.Size(351, 27);
            this.Kyazar.TabIndex = 82;
            // 
            // Kad
            // 
            this.Kad.Location = new System.Drawing.Point(1043, 153);
            this.Kad.Name = "Kad";
            this.Kad.Size = new System.Drawing.Size(351, 27);
            this.Kad.TabIndex = 83;
            // 
            // Ktip
            // 
            this.Ktip.FormattingEnabled = true;
            this.Ktip.Location = new System.Drawing.Point(1043, 111);
            this.Ktip.Name = "Ktip";
            this.Ktip.Size = new System.Drawing.Size(351, 28);
            this.Ktip.TabIndex = 84;
            // 
            // Klistele
            // 
            this.Klistele.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Klistele.Location = new System.Drawing.Point(865, 346);
            this.Klistele.Name = "Klistele";
            this.Klistele.Size = new System.Drawing.Size(135, 51);
            this.Klistele.TabIndex = 85;
            this.Klistele.Text = "Listele";
            this.Klistele.UseVisualStyleBackColor = true;
            this.Klistele.Click += new System.EventHandler(this.Klistele_Click);
            // 
            // Kara
            // 
            this.Kara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kara.Location = new System.Drawing.Point(1113, 424);
            this.Kara.Name = "Kara";
            this.Kara.Size = new System.Drawing.Size(135, 51);
            this.Kara.TabIndex = 86;
            this.Kara.Text = "Ara";
            this.Kara.UseVisualStyleBackColor = true;
            this.Kara.Click += new System.EventHandler(this.Kara_Click);
            // 
            // Kguncelle
            // 
            this.Kguncelle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kguncelle.Location = new System.Drawing.Point(1352, 347);
            this.Kguncelle.Name = "Kguncelle";
            this.Kguncelle.Size = new System.Drawing.Size(135, 51);
            this.Kguncelle.TabIndex = 87;
            this.Kguncelle.Text = "Güncelle";
            this.Kguncelle.UseVisualStyleBackColor = true;
            this.Kguncelle.Click += new System.EventHandler(this.Kguncelle_Click);
            // 
            // Ksil
            // 
            this.Ksil.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ksil.Location = new System.Drawing.Point(1194, 347);
            this.Ksil.Name = "Ksil";
            this.Ksil.Size = new System.Drawing.Size(135, 51);
            this.Ksil.TabIndex = 88;
            this.Ksil.Text = "Sil";
            this.Ksil.UseVisualStyleBackColor = true;
            this.Ksil.Click += new System.EventHandler(this.Ksil_Click);
            // 
            // Kekle
            // 
            this.Kekle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kekle.Location = new System.Drawing.Point(1022, 347);
            this.Kekle.Name = "Kekle";
            this.Kekle.Size = new System.Drawing.Size(135, 51);
            this.Kekle.TabIndex = 89;
            this.Kekle.Text = "Ekle";
            this.Kekle.UseVisualStyleBackColor = true;
            this.Kekle.Click += new System.EventHandler(this.Kekle_Click);
            // 
            // btCikis
            // 
            this.btCikis.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btCikis.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCikis.Location = new System.Drawing.Point(1361, 532);
            this.btCikis.Name = "btCikis";
            this.btCikis.Size = new System.Drawing.Size(144, 74);
            this.btCikis.TabIndex = 156;
            this.btCikis.Text = "ÇIKIŞ";
            this.btCikis.UseVisualStyleBackColor = false;
            this.btCikis.Click += new System.EventHandler(this.btCikis_Click);
            // 
            // Ftip
            // 
            this.Ftip.FormattingEnabled = true;
            this.Ftip.Location = new System.Drawing.Point(270, 436);
            this.Ftip.Name = "Ftip";
            this.Ftip.Size = new System.Drawing.Size(351, 28);
            this.Ftip.TabIndex = 166;
            // 
            // Fad
            // 
            this.Fad.Location = new System.Drawing.Point(270, 478);
            this.Fad.Name = "Fad";
            this.Fad.Size = new System.Drawing.Size(351, 27);
            this.Fad.TabIndex = 165;
            // 
            // Fyil
            // 
            this.Fyil.Location = new System.Drawing.Point(270, 524);
            this.Fyil.Name = "Fyil";
            this.Fyil.Size = new System.Drawing.Size(351, 27);
            this.Fyil.TabIndex = 164;
            // 
            // Fkategori
            // 
            this.Fkategori.Location = new System.Drawing.Point(270, 571);
            this.Fkategori.Name = "Fkategori";
            this.Fkategori.Size = new System.Drawing.Size(351, 27);
            this.Fkategori.TabIndex = 163;
            // 
            // Furunkod
            // 
            this.Furunkod.Location = new System.Drawing.Point(270, 394);
            this.Furunkod.Name = "Furunkod";
            this.Furunkod.Size = new System.Drawing.Size(351, 27);
            this.Furunkod.TabIndex = 162;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(92, 436);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(198, 33);
            this.label9.TabIndex = 161;
            this.label9.Text = "Ürün Tipi:";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(92, 394);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 33);
            this.label10.TabIndex = 160;
            this.label10.Text = "Ürün Kodu:";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(92, 478);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(198, 33);
            this.label11.TabIndex = 159;
            this.label11.Text = "Adı:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(92, 524);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(198, 33);
            this.label12.TabIndex = 158;
            this.label12.Text = "Çıkış Yılı:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(92, 571);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(198, 33);
            this.label13.TabIndex = 157;
            this.label13.Text = "Kategori No:";
            // 
            // Fekle
            // 
            this.Fekle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fekle.Location = new System.Drawing.Point(216, 639);
            this.Fekle.Name = "Fekle";
            this.Fekle.Size = new System.Drawing.Size(135, 51);
            this.Fekle.TabIndex = 171;
            this.Fekle.Text = "Ekle";
            this.Fekle.UseVisualStyleBackColor = true;
            this.Fekle.Click += new System.EventHandler(this.Fekle_Click);
            // 
            // Fsil
            // 
            this.Fsil.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fsil.Location = new System.Drawing.Point(388, 639);
            this.Fsil.Name = "Fsil";
            this.Fsil.Size = new System.Drawing.Size(135, 51);
            this.Fsil.TabIndex = 170;
            this.Fsil.Text = "Sil";
            this.Fsil.UseVisualStyleBackColor = true;
            this.Fsil.Click += new System.EventHandler(this.Fsil_Click);
            // 
            // Fguncelle
            // 
            this.Fguncelle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fguncelle.Location = new System.Drawing.Point(546, 639);
            this.Fguncelle.Name = "Fguncelle";
            this.Fguncelle.Size = new System.Drawing.Size(135, 51);
            this.Fguncelle.TabIndex = 169;
            this.Fguncelle.Text = "Güncelle";
            this.Fguncelle.UseVisualStyleBackColor = true;
            this.Fguncelle.Click += new System.EventHandler(this.Fguncelle_Click);
            // 
            // Fara
            // 
            this.Fara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fara.Location = new System.Drawing.Point(721, 639);
            this.Fara.Name = "Fara";
            this.Fara.Size = new System.Drawing.Size(135, 51);
            this.Fara.TabIndex = 168;
            this.Fara.Text = "Ara";
            this.Fara.UseVisualStyleBackColor = true;
            this.Fara.Click += new System.EventHandler(this.Fara_Click);
            // 
            // Flistele
            // 
            this.Flistele.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Flistele.Location = new System.Drawing.Point(59, 638);
            this.Flistele.Name = "Flistele";
            this.Flistele.Size = new System.Drawing.Size(135, 51);
            this.Flistele.TabIndex = 167;
            this.Flistele.Text = "Listele";
            this.Flistele.UseVisualStyleBackColor = true;
            this.Flistele.Click += new System.EventHandler(this.Flistele_Click);
            // 
            // btToplam
            // 
            this.btToplam.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btToplam.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btToplam.Location = new System.Drawing.Point(1125, 532);
            this.btToplam.Name = "btToplam";
            this.btToplam.Size = new System.Drawing.Size(144, 74);
            this.btToplam.TabIndex = 172;
            this.btToplam.Text = "Toplam Ürün Miktarları";
            this.btToplam.UseVisualStyleBackColor = false;
            this.btToplam.Click += new System.EventHandler(this.btToplam_Click);
            // 
            // Urun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1590, 728);
            this.Controls.Add(this.btToplam);
            this.Controls.Add(this.Fekle);
            this.Controls.Add(this.Fsil);
            this.Controls.Add(this.Fguncelle);
            this.Controls.Add(this.Fara);
            this.Controls.Add(this.Flistele);
            this.Controls.Add(this.Ftip);
            this.Controls.Add(this.Fad);
            this.Controls.Add(this.Fyil);
            this.Controls.Add(this.Fkategori);
            this.Controls.Add(this.Furunkod);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btCikis);
            this.Controls.Add(this.Kekle);
            this.Controls.Add(this.Ksil);
            this.Controls.Add(this.Kguncelle);
            this.Controls.Add(this.Kara);
            this.Controls.Add(this.Klistele);
            this.Controls.Add(this.Ktip);
            this.Controls.Add(this.Kad);
            this.Controls.Add(this.Kyazar);
            this.Controls.Add(this.Kkategori);
            this.Controls.Add(this.Kyayinevi);
            this.Controls.Add(this.Kurunkod);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dbUrun);
            this.Name = "Urun";
            this.Text = "Urun";
            this.Load += new System.EventHandler(this.Urun_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dbUrun)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dbUrun;
        private Label label4;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox Kurunkod;
        private TextBox Kyayinevi;
        private TextBox Kkategori;
        private TextBox Kyazar;
        private TextBox Kad;
        private ComboBox Ktip;
        private Button Klistele;
        private Button Kara;
        private Button Kguncelle;
        private Button Ksil;
        private Button Kekle;
        private Button btCikis;
        private ComboBox Ftip;
        private TextBox Fad;
        private TextBox Fyil;
        private TextBox Fkategori;
        private TextBox Furunkod;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Button Fekle;
        private Button Fsil;
        private Button Fguncelle;
        private Button Fara;
        private Button Flistele;
        private Button btToplam;
    }
}