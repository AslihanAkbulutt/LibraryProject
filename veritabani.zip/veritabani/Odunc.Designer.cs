﻿namespace veritabani
{
    partial class Odunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCikis = new System.Windows.Forms.Button();
            this.Kekle = new System.Windows.Forms.Button();
            this.Ksil = new System.Windows.Forms.Button();
            this.Kguncelle = new System.Windows.Forms.Button();
            this.Kara = new System.Windows.Forms.Button();
            this.Klistele = new System.Windows.Forms.Button();
            this.dateKodunc = new System.Windows.Forms.DateTimePicker();
            this.dateKiade = new System.Windows.Forms.DateTimePicker();
            this.Kuyeno = new System.Windows.Forms.TextBox();
            this.Kgorevlino = new System.Windows.Forms.TextBox();
            this.Kurunkod = new System.Windows.Forms.TextBox();
            this.kayitNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Oekle = new System.Windows.Forms.Button();
            this.Osil = new System.Windows.Forms.Button();
            this.Oguncelle = new System.Windows.Forms.Button();
            this.Oara = new System.Windows.Forms.Button();
            this.Olistele = new System.Windows.Forms.Button();
            this.dateOdunc = new System.Windows.Forms.DateTimePicker();
            this.Ouyeno = new System.Windows.Forms.TextBox();
            this.Ogorevlino = new System.Windows.Forms.TextBox();
            this.Ourunkod = new System.Windows.Forms.TextBox();
            this.oduncNo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dbOdunc = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dbOdunc)).BeginInit();
            this.SuspendLayout();
            // 
            // btCikis
            // 
            this.btCikis.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btCikis.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCikis.Location = new System.Drawing.Point(1405, 608);
            this.btCikis.Name = "btCikis";
            this.btCikis.Size = new System.Drawing.Size(144, 74);
            this.btCikis.TabIndex = 155;
            this.btCikis.Text = "ÇIKIŞ";
            this.btCikis.UseVisualStyleBackColor = false;
            this.btCikis.Click += new System.EventHandler(this.btCikis_Click);
            // 
            // Kekle
            // 
            this.Kekle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kekle.Location = new System.Drawing.Point(630, 533);
            this.Kekle.Name = "Kekle";
            this.Kekle.Size = new System.Drawing.Size(123, 61);
            this.Kekle.TabIndex = 154;
            this.Kekle.Text = "Kayıt Ekle";
            this.Kekle.UseVisualStyleBackColor = true;
            this.Kekle.Click += new System.EventHandler(this.Kekle_Click);
            // 
            // Ksil
            // 
            this.Ksil.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ksil.Location = new System.Drawing.Point(630, 616);
            this.Ksil.Name = "Ksil";
            this.Ksil.Size = new System.Drawing.Size(123, 59);
            this.Ksil.TabIndex = 153;
            this.Ksil.Text = "Kayıt Sil";
            this.Ksil.UseVisualStyleBackColor = true;
            this.Ksil.Click += new System.EventHandler(this.Ksil_Click);
            // 
            // Kguncelle
            // 
            this.Kguncelle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kguncelle.Location = new System.Drawing.Point(822, 450);
            this.Kguncelle.Name = "Kguncelle";
            this.Kguncelle.Size = new System.Drawing.Size(123, 63);
            this.Kguncelle.TabIndex = 152;
            this.Kguncelle.Text = "Güncelle";
            this.Kguncelle.UseVisualStyleBackColor = true;
            this.Kguncelle.Click += new System.EventHandler(this.Kguncelle_Click);
            // 
            // Kara
            // 
            this.Kara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kara.Location = new System.Drawing.Point(822, 533);
            this.Kara.Name = "Kara";
            this.Kara.Size = new System.Drawing.Size(123, 61);
            this.Kara.TabIndex = 151;
            this.Kara.Text = "Ara";
            this.Kara.UseVisualStyleBackColor = true;
            this.Kara.Click += new System.EventHandler(this.Kara_Click);
            // 
            // Klistele
            // 
            this.Klistele.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Klistele.Location = new System.Drawing.Point(630, 450);
            this.Klistele.Name = "Klistele";
            this.Klistele.Size = new System.Drawing.Size(123, 63);
            this.Klistele.TabIndex = 150;
            this.Klistele.Text = "Listele";
            this.Klistele.UseVisualStyleBackColor = true;
            this.Klistele.Click += new System.EventHandler(this.Klistele_Click);
            // 
            // dateKodunc
            // 
            this.dateKodunc.Location = new System.Drawing.Point(307, 667);
            this.dateKodunc.Name = "dateKodunc";
            this.dateKodunc.Size = new System.Drawing.Size(187, 27);
            this.dateKodunc.TabIndex = 149;
            // 
            // dateKiade
            // 
            this.dateKiade.Location = new System.Drawing.Point(307, 727);
            this.dateKiade.Name = "dateKiade";
            this.dateKiade.Size = new System.Drawing.Size(187, 27);
            this.dateKiade.TabIndex = 148;
            // 
            // Kuyeno
            // 
            this.Kuyeno.Location = new System.Drawing.Point(307, 502);
            this.Kuyeno.Name = "Kuyeno";
            this.Kuyeno.Size = new System.Drawing.Size(187, 27);
            this.Kuyeno.TabIndex = 147;
            // 
            // Kgorevlino
            // 
            this.Kgorevlino.Location = new System.Drawing.Point(307, 551);
            this.Kgorevlino.Name = "Kgorevlino";
            this.Kgorevlino.Size = new System.Drawing.Size(187, 27);
            this.Kgorevlino.TabIndex = 146;
            // 
            // Kurunkod
            // 
            this.Kurunkod.Location = new System.Drawing.Point(307, 602);
            this.Kurunkod.Name = "Kurunkod";
            this.Kurunkod.Size = new System.Drawing.Size(187, 27);
            this.Kurunkod.TabIndex = 145;
            // 
            // kayitNo
            // 
            this.kayitNo.Location = new System.Drawing.Point(307, 452);
            this.kayitNo.Name = "kayitNo";
            this.kayitNo.Size = new System.Drawing.Size(187, 27);
            this.kayitNo.TabIndex = 144;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(112, 729);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 34);
            this.label8.TabIndex = 143;
            this.label8.Text = "İade Tarihi:";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(112, 452);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 34);
            this.label9.TabIndex = 142;
            this.label9.Text = "No:";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(112, 654);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(144, 49);
            this.label10.TabIndex = 141;
            this.label10.Text = "Ödünç Alınan Tarih:";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(112, 502);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(144, 34);
            this.label11.TabIndex = 140;
            this.label11.Text = "Üye Kişi No:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(112, 551);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(162, 34);
            this.label12.TabIndex = 139;
            this.label12.Text = "Görevli Kişi No:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(112, 602);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 34);
            this.label13.TabIndex = 138;
            this.label13.Text = "Ürün No:";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(216, 394);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(278, 34);
            this.label14.TabIndex = 137;
            this.label14.Text = "KAYIT(ARŞİV) İŞLEMLERİ";
            // 
            // Oekle
            // 
            this.Oekle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Oekle.Location = new System.Drawing.Point(1441, 142);
            this.Oekle.Name = "Oekle";
            this.Oekle.Size = new System.Drawing.Size(123, 61);
            this.Oekle.TabIndex = 136;
            this.Oekle.Text = "Ödünç Alma";
            this.Oekle.UseVisualStyleBackColor = true;
            this.Oekle.Click += new System.EventHandler(this.Oekle_Click);
            // 
            // Osil
            // 
            this.Osil.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Osil.Location = new System.Drawing.Point(1441, 225);
            this.Osil.Name = "Osil";
            this.Osil.Size = new System.Drawing.Size(123, 59);
            this.Osil.TabIndex = 135;
            this.Osil.Text = "İade Etme";
            this.Osil.UseVisualStyleBackColor = true;
            this.Osil.Click += new System.EventHandler(this.Osil_Click);
            // 
            // Oguncelle
            // 
            this.Oguncelle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Oguncelle.Location = new System.Drawing.Point(1581, 59);
            this.Oguncelle.Name = "Oguncelle";
            this.Oguncelle.Size = new System.Drawing.Size(123, 63);
            this.Oguncelle.TabIndex = 134;
            this.Oguncelle.Text = "Güncelle";
            this.Oguncelle.UseVisualStyleBackColor = true;
            this.Oguncelle.Click += new System.EventHandler(this.Oguncelle_Click);
            // 
            // Oara
            // 
            this.Oara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Oara.Location = new System.Drawing.Point(1581, 142);
            this.Oara.Name = "Oara";
            this.Oara.Size = new System.Drawing.Size(123, 61);
            this.Oara.TabIndex = 133;
            this.Oara.Text = "Ara";
            this.Oara.UseVisualStyleBackColor = true;
            this.Oara.Click += new System.EventHandler(this.Oara_Click);
            // 
            // Olistele
            // 
            this.Olistele.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Olistele.Location = new System.Drawing.Point(1441, 59);
            this.Olistele.Name = "Olistele";
            this.Olistele.Size = new System.Drawing.Size(123, 63);
            this.Olistele.TabIndex = 132;
            this.Olistele.Text = "Listele";
            this.Olistele.UseVisualStyleBackColor = true;
            this.Olistele.Click += new System.EventHandler(this.Olistele_Click);
            // 
            // dateOdunc
            // 
            this.dateOdunc.Location = new System.Drawing.Point(1163, 142);
            this.dateOdunc.Name = "dateOdunc";
            this.dateOdunc.Size = new System.Drawing.Size(187, 27);
            this.dateOdunc.TabIndex = 131;
            // 
            // Ouyeno
            // 
            this.Ouyeno.Location = new System.Drawing.Point(1163, 204);
            this.Ouyeno.Name = "Ouyeno";
            this.Ouyeno.Size = new System.Drawing.Size(187, 27);
            this.Ouyeno.TabIndex = 130;
            // 
            // Ogorevlino
            // 
            this.Ogorevlino.Location = new System.Drawing.Point(1163, 253);
            this.Ogorevlino.Name = "Ogorevlino";
            this.Ogorevlino.Size = new System.Drawing.Size(187, 27);
            this.Ogorevlino.TabIndex = 129;
            // 
            // Ourunkod
            // 
            this.Ourunkod.Location = new System.Drawing.Point(1163, 304);
            this.Ourunkod.Name = "Ourunkod";
            this.Ourunkod.Size = new System.Drawing.Size(187, 27);
            this.Ourunkod.TabIndex = 128;
            // 
            // oduncNo
            // 
            this.oduncNo.Location = new System.Drawing.Point(1163, 77);
            this.oduncNo.Name = "oduncNo";
            this.oduncNo.Size = new System.Drawing.Size(187, 27);
            this.oduncNo.TabIndex = 127;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(983, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 34);
            this.label6.TabIndex = 126;
            this.label6.Text = "No:";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(983, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 49);
            this.label5.TabIndex = 125;
            this.label5.Text = "Ödünç Alınan Tarih:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(983, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 34);
            this.label4.TabIndex = 124;
            this.label4.Text = "Üye Kişi No:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(983, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 34);
            this.label3.TabIndex = 123;
            this.label3.Text = "Görevli Kişi No:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(983, 304);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 34);
            this.label2.TabIndex = 122;
            this.label2.Text = "Ürün No:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(1098, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 34);
            this.label1.TabIndex = 121;
            this.label1.Text = "ÖDÜNÇ İŞLEMLERİ";
            // 
            // dbOdunc
            // 
            this.dbOdunc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dbOdunc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbOdunc.Location = new System.Drawing.Point(12, 12);
            this.dbOdunc.Name = "dbOdunc";
            this.dbOdunc.RowHeadersWidth = 51;
            this.dbOdunc.RowTemplate.Height = 29;
            this.dbOdunc.Size = new System.Drawing.Size(933, 369);
            this.dbOdunc.TabIndex = 120;
            // 
            // Odunc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1716, 815);
            this.Controls.Add(this.btCikis);
            this.Controls.Add(this.Kekle);
            this.Controls.Add(this.Ksil);
            this.Controls.Add(this.Kguncelle);
            this.Controls.Add(this.Kara);
            this.Controls.Add(this.Klistele);
            this.Controls.Add(this.dateKodunc);
            this.Controls.Add(this.dateKiade);
            this.Controls.Add(this.Kuyeno);
            this.Controls.Add(this.Kgorevlino);
            this.Controls.Add(this.Kurunkod);
            this.Controls.Add(this.kayitNo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.Oekle);
            this.Controls.Add(this.Osil);
            this.Controls.Add(this.Oguncelle);
            this.Controls.Add(this.Oara);
            this.Controls.Add(this.Olistele);
            this.Controls.Add(this.dateOdunc);
            this.Controls.Add(this.Ouyeno);
            this.Controls.Add(this.Ogorevlino);
            this.Controls.Add(this.Ourunkod);
            this.Controls.Add(this.oduncNo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dbOdunc);
            this.Name = "Odunc";
            this.Text = "Odunc";
            ((System.ComponentModel.ISupportInitialize)(this.dbOdunc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btCikis;
        private Button Kekle;
        private Button Ksil;
        private Button Kguncelle;
        private Button Kara;
        private Button Klistele;
        private DateTimePicker dateKodunc;
        private DateTimePicker dateKiade;
        private TextBox Kuyeno;
        private TextBox Kgorevlino;
        private TextBox Kurunkod;
        private TextBox kayitNo;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Button Oekle;
        private Button Osil;
        private Button Oguncelle;
        private Button Oara;
        private Button Olistele;
        private DateTimePicker dateOdunc;
        private TextBox Ouyeno;
        private TextBox Ogorevlino;
        private TextBox Ourunkod;
        private TextBox oduncNo;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView dbOdunc;
    }
}