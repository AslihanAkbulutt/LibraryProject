﻿namespace veritabani
{
    partial class Diger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.YAara = new System.Windows.Forms.Button();
            this.YAlistele = new System.Windows.Forms.Button();
            this.YAguncelle = new System.Windows.Forms.Button();
            this.YAsil = new System.Windows.Forms.Button();
            this.YAekle = new System.Windows.Forms.Button();
            this.Fara = new System.Windows.Forms.Button();
            this.Flistele = new System.Windows.Forms.Button();
            this.Fguncelle = new System.Windows.Forms.Button();
            this.Fsil = new System.Windows.Forms.Button();
            this.Fekle = new System.Windows.Forms.Button();
            this.Yara = new System.Windows.Forms.Button();
            this.Ylistele = new System.Windows.Forms.Button();
            this.Yguncelle = new System.Windows.Forms.Button();
            this.Ysil = new System.Windows.Forms.Button();
            this.Yekle = new System.Windows.Forms.Button();
            this.YAtelefon = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.YAad = new System.Windows.Forms.TextBox();
            this.YAyayievino = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.Fad = new System.Windows.Forms.TextBox();
            this.Fkategori = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Ysoyad = new System.Windows.Forms.TextBox();
            this.Yad = new System.Windows.Forms.TextBox();
            this.Yyazarno = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Kad = new System.Windows.Forms.TextBox();
            this.Kkategori = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dbDiger = new System.Windows.Forms.DataGridView();
            this.Kara = new System.Windows.Forms.Button();
            this.Klistele = new System.Windows.Forms.Button();
            this.Kguncelle = new System.Windows.Forms.Button();
            this.Ksil = new System.Windows.Forms.Button();
            this.Kekle = new System.Windows.Forms.Button();
            this.btCikis = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dbDiger)).BeginInit();
            this.SuspendLayout();
            // 
            // YAara
            // 
            this.YAara.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.YAara.Location = new System.Drawing.Point(1271, 276);
            this.YAara.Name = "YAara";
            this.YAara.Size = new System.Drawing.Size(119, 35);
            this.YAara.TabIndex = 171;
            this.YAara.Text = "ARA";
            this.YAara.UseVisualStyleBackColor = true;
            this.YAara.Click += new System.EventHandler(this.YAara_Click);
            // 
            // YAlistele
            // 
            this.YAlistele.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.YAlistele.Location = new System.Drawing.Point(1119, 222);
            this.YAlistele.Name = "YAlistele";
            this.YAlistele.Size = new System.Drawing.Size(119, 32);
            this.YAlistele.TabIndex = 170;
            this.YAlistele.Text = "LİSTELE";
            this.YAlistele.UseVisualStyleBackColor = true;
            this.YAlistele.Click += new System.EventHandler(this.YAlistele_Click);
            // 
            // YAguncelle
            // 
            this.YAguncelle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.YAguncelle.Location = new System.Drawing.Point(1271, 222);
            this.YAguncelle.Name = "YAguncelle";
            this.YAguncelle.Size = new System.Drawing.Size(118, 32);
            this.YAguncelle.TabIndex = 169;
            this.YAguncelle.Text = "GÜNCELLE";
            this.YAguncelle.UseVisualStyleBackColor = true;
            this.YAguncelle.Click += new System.EventHandler(this.YAguncelle_Click);
            // 
            // YAsil
            // 
            this.YAsil.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.YAsil.Location = new System.Drawing.Point(1119, 336);
            this.YAsil.Name = "YAsil";
            this.YAsil.Size = new System.Drawing.Size(118, 32);
            this.YAsil.TabIndex = 168;
            this.YAsil.Text = "SİL";
            this.YAsil.UseVisualStyleBackColor = true;
            this.YAsil.Click += new System.EventHandler(this.YAsil_Click);
            // 
            // YAekle
            // 
            this.YAekle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.YAekle.Location = new System.Drawing.Point(1119, 276);
            this.YAekle.Name = "YAekle";
            this.YAekle.Size = new System.Drawing.Size(118, 35);
            this.YAekle.TabIndex = 167;
            this.YAekle.Text = "EKLE";
            this.YAekle.UseVisualStyleBackColor = true;
            this.YAekle.Click += new System.EventHandler(this.YAekle_Click);
            // 
            // Fara
            // 
            this.Fara.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fara.Location = new System.Drawing.Point(892, 276);
            this.Fara.Name = "Fara";
            this.Fara.Size = new System.Drawing.Size(119, 35);
            this.Fara.TabIndex = 161;
            this.Fara.Text = "ARA";
            this.Fara.UseVisualStyleBackColor = true;
            this.Fara.Click += new System.EventHandler(this.Fara_Click);
            // 
            // Flistele
            // 
            this.Flistele.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Flistele.Location = new System.Drawing.Point(723, 222);
            this.Flistele.Name = "Flistele";
            this.Flistele.Size = new System.Drawing.Size(119, 32);
            this.Flistele.TabIndex = 160;
            this.Flistele.Text = "LİSTELE";
            this.Flistele.UseVisualStyleBackColor = true;
            this.Flistele.Click += new System.EventHandler(this.Flistele_Click);
            // 
            // Fguncelle
            // 
            this.Fguncelle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fguncelle.Location = new System.Drawing.Point(892, 222);
            this.Fguncelle.Name = "Fguncelle";
            this.Fguncelle.Size = new System.Drawing.Size(118, 32);
            this.Fguncelle.TabIndex = 159;
            this.Fguncelle.Text = "GÜNCELLE";
            this.Fguncelle.UseVisualStyleBackColor = true;
            this.Fguncelle.Click += new System.EventHandler(this.Fguncelle_Click);
            // 
            // Fsil
            // 
            this.Fsil.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fsil.Location = new System.Drawing.Point(724, 336);
            this.Fsil.Name = "Fsil";
            this.Fsil.Size = new System.Drawing.Size(118, 32);
            this.Fsil.TabIndex = 158;
            this.Fsil.Text = "SİL";
            this.Fsil.UseVisualStyleBackColor = true;
            this.Fsil.Click += new System.EventHandler(this.Fsil_Click);
            // 
            // Fekle
            // 
            this.Fekle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Fekle.Location = new System.Drawing.Point(724, 276);
            this.Fekle.Name = "Fekle";
            this.Fekle.Size = new System.Drawing.Size(118, 35);
            this.Fekle.TabIndex = 157;
            this.Fekle.Text = "EKLE";
            this.Fekle.UseVisualStyleBackColor = true;
            this.Fekle.Click += new System.EventHandler(this.Fekle_Click);
            // 
            // Yara
            // 
            this.Yara.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Yara.Location = new System.Drawing.Point(171, 276);
            this.Yara.Name = "Yara";
            this.Yara.Size = new System.Drawing.Size(119, 35);
            this.Yara.TabIndex = 156;
            this.Yara.Text = "ARA";
            this.Yara.UseVisualStyleBackColor = true;
            this.Yara.Click += new System.EventHandler(this.Yara_Click);
            // 
            // Ylistele
            // 
            this.Ylistele.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ylistele.Location = new System.Drawing.Point(19, 218);
            this.Ylistele.Name = "Ylistele";
            this.Ylistele.Size = new System.Drawing.Size(119, 32);
            this.Ylistele.TabIndex = 155;
            this.Ylistele.Text = "LİSTELE";
            this.Ylistele.UseVisualStyleBackColor = true;
            this.Ylistele.Click += new System.EventHandler(this.Ylistele_Click);
            // 
            // Yguncelle
            // 
            this.Yguncelle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Yguncelle.Location = new System.Drawing.Point(171, 218);
            this.Yguncelle.Name = "Yguncelle";
            this.Yguncelle.Size = new System.Drawing.Size(118, 36);
            this.Yguncelle.TabIndex = 154;
            this.Yguncelle.Text = "GÜNCELLE";
            this.Yguncelle.UseVisualStyleBackColor = true;
            this.Yguncelle.Click += new System.EventHandler(this.Yguncelle_Click);
            // 
            // Ysil
            // 
            this.Ysil.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ysil.Location = new System.Drawing.Point(19, 336);
            this.Ysil.Name = "Ysil";
            this.Ysil.Size = new System.Drawing.Size(118, 32);
            this.Ysil.TabIndex = 153;
            this.Ysil.Text = "SİL";
            this.Ysil.UseVisualStyleBackColor = true;
            this.Ysil.Click += new System.EventHandler(this.Ysil_Click);
            // 
            // Yekle
            // 
            this.Yekle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Yekle.Location = new System.Drawing.Point(19, 276);
            this.Yekle.Name = "Yekle";
            this.Yekle.Size = new System.Drawing.Size(118, 35);
            this.Yekle.TabIndex = 152;
            this.Yekle.Text = "EKLE";
            this.Yekle.UseVisualStyleBackColor = true;
            this.Yekle.Click += new System.EventHandler(this.Yekle_Click);
            // 
            // YAtelefon
            // 
            this.YAtelefon.Location = new System.Drawing.Point(1235, 171);
            this.YAtelefon.Name = "YAtelefon";
            this.YAtelefon.Size = new System.Drawing.Size(155, 27);
            this.YAtelefon.TabIndex = 151;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(1103, 175);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(126, 34);
            this.label21.TabIndex = 150;
            this.label21.Text = "Telefon:";
            // 
            // YAad
            // 
            this.YAad.Location = new System.Drawing.Point(1235, 121);
            this.YAad.Name = "YAad";
            this.YAad.Size = new System.Drawing.Size(155, 27);
            this.YAad.TabIndex = 149;
            // 
            // YAyayievino
            // 
            this.YAyayievino.Location = new System.Drawing.Point(1235, 64);
            this.YAyayievino.Name = "YAyayievino";
            this.YAyayievino.Size = new System.Drawing.Size(155, 27);
            this.YAyayievino.TabIndex = 148;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(1103, 68);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(126, 32);
            this.label19.TabIndex = 147;
            this.label19.Text = "Yayinevi No:";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(1103, 125);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(126, 34);
            this.label20.TabIndex = 146;
            this.label20.Text = "Ad:";
            // 
            // Fad
            // 
            this.Fad.Location = new System.Drawing.Point(856, 121);
            this.Fad.Name = "Fad";
            this.Fad.Size = new System.Drawing.Size(155, 27);
            this.Fad.TabIndex = 145;
            // 
            // Fkategori
            // 
            this.Fkategori.Location = new System.Drawing.Point(856, 64);
            this.Fkategori.Name = "Fkategori";
            this.Fkategori.Size = new System.Drawing.Size(155, 27);
            this.Fkategori.TabIndex = 144;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(724, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 32);
            this.label16.TabIndex = 143;
            this.label16.Text = "Kategori No:";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(724, 125);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(126, 34);
            this.label18.TabIndex = 142;
            this.label18.Text = "Kategori Adı:";
            // 
            // Ysoyad
            // 
            this.Ysoyad.Location = new System.Drawing.Point(126, 160);
            this.Ysoyad.Name = "Ysoyad";
            this.Ysoyad.Size = new System.Drawing.Size(155, 27);
            this.Ysoyad.TabIndex = 137;
            // 
            // Yad
            // 
            this.Yad.Location = new System.Drawing.Point(126, 110);
            this.Yad.Name = "Yad";
            this.Yad.Size = new System.Drawing.Size(155, 27);
            this.Yad.TabIndex = 136;
            // 
            // Yyazarno
            // 
            this.Yyazarno.Location = new System.Drawing.Point(126, 64);
            this.Yyazarno.Name = "Yyazarno";
            this.Yyazarno.Size = new System.Drawing.Size(155, 27);
            this.Yyazarno.TabIndex = 135;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(19, 114);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 34);
            this.label14.TabIndex = 134;
            this.label14.Text = "Ad:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(19, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 34);
            this.label13.TabIndex = 133;
            this.label13.Text = "Soyad:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(19, 68);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 34);
            this.label12.TabIndex = 132;
            this.label12.Text = "Yazar No:";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(1184, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(221, 34);
            this.label5.TabIndex = 131;
            this.label5.Text = "YAYİNEVİ İŞLEMLERİ";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(739, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(293, 34);
            this.label4.TabIndex = 130;
            this.label4.Text = "FİLM KATEGORİ İŞLEMLERİ";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(94, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 34);
            this.label2.TabIndex = 128;
            this.label2.Text = "YAZAR İŞLEMLERİ";
            // 
            // Kad
            // 
            this.Kad.Location = new System.Drawing.Point(481, 121);
            this.Kad.Name = "Kad";
            this.Kad.Size = new System.Drawing.Size(155, 27);
            this.Kad.TabIndex = 176;
            // 
            // Kkategori
            // 
            this.Kkategori.Location = new System.Drawing.Point(481, 64);
            this.Kkategori.Name = "Kkategori";
            this.Kkategori.Size = new System.Drawing.Size(155, 27);
            this.Kkategori.TabIndex = 175;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(349, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 32);
            this.label1.TabIndex = 174;
            this.label1.Text = "Kategori No:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(349, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 34);
            this.label3.TabIndex = 173;
            this.label3.Text = "Kategori Adı:";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(369, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(291, 34);
            this.label6.TabIndex = 172;
            this.label6.Text = "KİTAP KATEGORİ İŞLEMLERİ";
            // 
            // dbDiger
            // 
            this.dbDiger.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dbDiger.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbDiger.Location = new System.Drawing.Point(254, 410);
            this.dbDiger.Name = "dbDiger";
            this.dbDiger.RowHeadersWidth = 51;
            this.dbDiger.RowTemplate.Height = 29;
            this.dbDiger.Size = new System.Drawing.Size(837, 296);
            this.dbDiger.TabIndex = 182;
            // 
            // Kara
            // 
            this.Kara.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kara.Location = new System.Drawing.Point(538, 272);
            this.Kara.Name = "Kara";
            this.Kara.Size = new System.Drawing.Size(119, 35);
            this.Kara.TabIndex = 187;
            this.Kara.Text = "ARA";
            this.Kara.UseVisualStyleBackColor = true;
            this.Kara.Click += new System.EventHandler(this.Kara_Click);
            // 
            // Klistele
            // 
            this.Klistele.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Klistele.Location = new System.Drawing.Point(369, 218);
            this.Klistele.Name = "Klistele";
            this.Klistele.Size = new System.Drawing.Size(119, 32);
            this.Klistele.TabIndex = 186;
            this.Klistele.Text = "LİSTELE";
            this.Klistele.UseVisualStyleBackColor = true;
            this.Klistele.Click += new System.EventHandler(this.Klistele_Click);
            // 
            // Kguncelle
            // 
            this.Kguncelle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kguncelle.Location = new System.Drawing.Point(538, 218);
            this.Kguncelle.Name = "Kguncelle";
            this.Kguncelle.Size = new System.Drawing.Size(118, 32);
            this.Kguncelle.TabIndex = 185;
            this.Kguncelle.Text = "GÜNCELLE";
            this.Kguncelle.UseVisualStyleBackColor = true;
            this.Kguncelle.Click += new System.EventHandler(this.Kguncelle_Click);
            // 
            // Ksil
            // 
            this.Ksil.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ksil.Location = new System.Drawing.Point(370, 332);
            this.Ksil.Name = "Ksil";
            this.Ksil.Size = new System.Drawing.Size(118, 32);
            this.Ksil.TabIndex = 184;
            this.Ksil.Text = "SİL";
            this.Ksil.UseVisualStyleBackColor = true;
            this.Ksil.Click += new System.EventHandler(this.Ksil_Click);
            // 
            // Kekle
            // 
            this.Kekle.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Kekle.Location = new System.Drawing.Point(370, 272);
            this.Kekle.Name = "Kekle";
            this.Kekle.Size = new System.Drawing.Size(118, 35);
            this.Kekle.TabIndex = 183;
            this.Kekle.Text = "EKLE";
            this.Kekle.UseVisualStyleBackColor = true;
            this.Kekle.Click += new System.EventHandler(this.Kekle_Click);
            // 
            // btCikis
            // 
            this.btCikis.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btCikis.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCikis.Location = new System.Drawing.Point(1261, 592);
            this.btCikis.Name = "btCikis";
            this.btCikis.Size = new System.Drawing.Size(144, 74);
            this.btCikis.TabIndex = 188;
            this.btCikis.Text = "ÇIKIŞ";
            this.btCikis.UseVisualStyleBackColor = false;
            this.btCikis.Click += new System.EventHandler(this.btCikis_Click);
            // 
            // Diger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1478, 718);
            this.Controls.Add(this.btCikis);
            this.Controls.Add(this.Kara);
            this.Controls.Add(this.Klistele);
            this.Controls.Add(this.Kguncelle);
            this.Controls.Add(this.Ksil);
            this.Controls.Add(this.Kekle);
            this.Controls.Add(this.dbDiger);
            this.Controls.Add(this.Kad);
            this.Controls.Add(this.Kkategori);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.YAara);
            this.Controls.Add(this.YAlistele);
            this.Controls.Add(this.YAguncelle);
            this.Controls.Add(this.YAsil);
            this.Controls.Add(this.YAekle);
            this.Controls.Add(this.Fara);
            this.Controls.Add(this.Flistele);
            this.Controls.Add(this.Fguncelle);
            this.Controls.Add(this.Fsil);
            this.Controls.Add(this.Fekle);
            this.Controls.Add(this.Yara);
            this.Controls.Add(this.Ylistele);
            this.Controls.Add(this.Yguncelle);
            this.Controls.Add(this.Ysil);
            this.Controls.Add(this.Yekle);
            this.Controls.Add(this.YAtelefon);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.YAad);
            this.Controls.Add(this.YAyayievino);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.Fad);
            this.Controls.Add(this.Fkategori);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.Ysoyad);
            this.Controls.Add(this.Yad);
            this.Controls.Add(this.Yyazarno);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Name = "Diger";
            this.Text = "Diger";
            this.Load += new System.EventHandler(this.Diger_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dbDiger)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button YAara;
        private Button YAlistele;
        private Button YAguncelle;
        private Button YAsil;
        private Button YAekle;
        private Button Fara;
        private Button Flistele;
        private Button Fguncelle;
        private Button Fsil;
        private Button Fekle;
        private Button Yara;
        private Button Ylistele;
        private Button Yguncelle;
        private Button Ysil;
        private Button Yekle;
        private TextBox YAtelefon;
        private Label label21;
        private TextBox YAad;
        private TextBox YAyayievino;
        private Label label19;
        private Label label20;
        private TextBox Fad;
        private TextBox Fkategori;
        private Label label16;
        private Label label18;
        private TextBox Ysoyad;
        private TextBox Yad;
        private TextBox Yyazarno;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label5;
        private Label label4;
        private Label label2;
        private TextBox Kad;
        private TextBox Kkategori;
        private Label label1;
        private Label label3;
        private Label label6;
        private DataGridView dbDiger;
        private Button Kara;
        private Button Klistele;
        private Button Kguncelle;
        private Button Ksil;
        private Button Kekle;
        private Button btCikis;
    }
}